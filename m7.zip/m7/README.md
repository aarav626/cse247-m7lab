Baseline student repo for CSE247/502N hashing lab.
