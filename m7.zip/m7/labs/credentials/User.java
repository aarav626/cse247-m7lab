package credentials;

public class User {
	// Add your Bridges Credentials Here!
	public static final String USERNAME = "srvijay";
	public static final String APIKEY 	= "104541764553";
}
