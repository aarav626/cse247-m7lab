package credentials;

public class User {
	// Add your Bridges Credentials Here!
	public static final String USERNAME = "";
	public static final String APIKEY 	= "";
}
