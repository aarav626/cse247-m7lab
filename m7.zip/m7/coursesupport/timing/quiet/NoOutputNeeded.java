package timing.quiet;

public class NoOutputNeeded {
	
	public final static NoOutputNeeded instance = new NoOutputNeeded();
	private NoOutputNeeded() { }

}
